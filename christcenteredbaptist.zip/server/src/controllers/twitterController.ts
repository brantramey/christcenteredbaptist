import { Request, Response } from 'express';
import { TwitterApi } from 'twitter-api-v2';
import { Tweet } from '../models/types';
import dotenv from 'dotenv';

dotenv.config();

// Twitter API configuration
const twitterClient = new TwitterApi({
  appKey: process.env.TWITTER_API_KEY || '',
  appSecret: process.env.TWITTER_API_SECRET || '',
  accessToken: process.env.TWITTER_ACCESS_TOKEN || '',
  accessSecret: process.env.TWITTER_ACCESS_SECRET || '',
});

// Get user profile by username
export const getUserProfile = async (req: Request, res: Response) => {
  try {
    const username = req.params.username;
    
    // For development/testing, return mock data if API keys aren't set
    if (!process.env.TWITTER_API_KEY) {
      return res.json({
        id: '123456789',
        name: 'Christ Centered Baptist',
        username: 'christcenteredbaptist',
        profileImageUrl: 'https://via.placeholder.com/200',
        description: 'Teaching Christ Through The Bible',
        followersCount: 250,
        followingCount: 100
      });
    }
    
    const user = await twitterClient.v2.userByUsername(username, {
      'user.fields': ['profile_image_url', 'description', 'public_metrics']
    });
    
    if (!user.data) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.json({
      id: user.data.id,
      name: user.data.name,
      username: user.data.username,
      profileImageUrl: user.data.profile_image_url,
      description: user.data.description,
      followersCount: user.data.public_metrics?.followers_count,
      followingCount: user.data.public_metrics?.following_count
    });
  } catch (error: any) {
    console.error('Error fetching Twitter user profile:', error);
    res.status(500).json({ message: 'Error fetching Twitter user profile', error: error.message });
  }
};

// Get user tweets
export const getUserTweets = async (req: Request, res: Response) => {
  try {
    const userId = req.params.userId;
    const count = parseInt(req.query.count as string) || 5;
    
    // For development/testing, return mock data if API keys aren't set
    if (!process.env.TWITTER_API_KEY) {
      const mockTweets: Tweet[] = [
        {
          id: '1',
          text: 'Join us this Sunday as we explore the meaning of salvation through Christ. #ChristCenteredBaptist #Salvation',
          createdAt: '2025-03-20T10:30:00Z',
          username: 'christcenteredbaptist',
          name: 'Christ Centered Baptist',
          profileImageUrl: 'https://via.placeholder.com/48'
        },
        {
          id: '2',
          text: '"For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life." - John 3:16 #BibleVerse',
          createdAt: '2025-03-18T14:15:00Z',
          username: 'christcenteredbaptist',
          name: 'Christ Centered Baptist',
          profileImageUrl: 'https://via.placeholder.com/48'
        },
        {
          id: '3',
          text: 'New post on our website about Amazing Grace, one of the most beloved hymns about salvation. Learn about its history and meaning. #Hymns #AmazingGrace',
          createdAt: '2025-03-15T09:45:00Z',
          username: 'christcenteredbaptist',
          name: 'Christ Centered Baptist',
          profileImageUrl: 'https://via.placeholder.com/48'
        }
      ];
      return res.json(mockTweets);
    }
    
    const tweets = await twitterClient.v2.userTimeline(userId, {
      max_results: count,
      'tweet.fields': ['created_at'],
      'user.fields': ['profile_image_url']
    });
    
    if (!tweets.data) {
      return res.json([]);
    }
    
    const formattedTweets: Tweet[] = tweets.data.data.map(tweet => ({
      id: tweet.id,
      text: tweet.text,
      createdAt: tweet.created_at || new Date().toISOString(),
      username: tweets.includes?.users?.[0]?.username || 'christcenteredbaptist',
      name: tweets.includes?.users?.[0]?.name || 'Christ Centered Baptist',
      profileImageUrl: tweets.includes?.users?.[0]?.profile_image_url || 'https://via.placeholder.com/48'
    }));
    
    res.json(formattedTweets);
  } catch (error: any) {
    console.error('Error fetching Twitter user tweets:', error);
    res.status(500).json({ message: 'Error fetching Twitter user tweets', error: error.message });
  }
};

// Search tweets
export const searchTweets = async (req: Request, res: Response) => {
  try {
    const query = req.query.q as string;
    const count = parseInt(req.query.count as string) || 10;
    
    if (!query) {
      return res.status(400).json({ message: 'Query parameter is required' });
    }
    
    // For development/testing, return mock data if API keys aren't set
    if (!process.env.TWITTER_API_KEY) {
      const mockTweets: Tweet[] = [
        {
          id: '1',
          text: `Search results for "${query}": Join us this Sunday as we explore the meaning of salvation through Christ. #ChristCenteredBaptist #Salvation`,
          createdAt: '2025-03-20T10:30:00Z',
          username: 'christcenteredbaptist',
          name: 'Christ Centered Baptist',
          profileImageUrl: 'https://via.placeholder.com/48'
        },
        {
          id: '2',
          text: `Search results for "${query}": "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life." - John 3:16 #BibleVerse`,
          createdAt: '2025-03-18T14:15:00Z',
          username: 'christcenteredbaptist',
          name: 'Christ Centered Baptist',
          profileImageUrl: 'https://via.placeholder.com/48'
        }
      ];
      return res.json(mockTweets);
    }
    
    const tweets = await twitterClient.v2.search(query, {
      max_results: count,
      'tweet.fields': ['created_at'],
      'user.fields': ['profile_image_url']
    });
    
    if (!tweets.data) {
      return res.json([]);
    }
    
    const formattedTweets: Tweet[] = tweets.data.data.map(tweet => ({
      id: tweet.id,
      text: tweet.text,
      createdAt: tweet.created_at || new Date().toISOString(),
      username: tweets.includes?.users?.find(user => user.id === tweet.author_id)?.username || 'unknown',
      name: tweets.includes?.users?.find(user => user.id === tweet.author_id)?.name || 'Unknown User',
      profileImageUrl: tweets.includes?.users?.find(user => user.id === tweet.author_id)?.profile_image_url || 'https://via.placeholder.com/48'
    }));
    
    res.json(formattedTweets);
  } catch (error: any) {
    console.error('Error searching tweets:', error);
    res.status(500).json({ message: 'Error searching tweets', error: error.message });
  }
};
