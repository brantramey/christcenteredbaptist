import React from 'react';
import BibleVerseCard from '../../components/BibleVerseCard/BibleVerseCard';
import WeeklyPost from '../../components/WeeklyPost/WeeklyPost';
import TwitterFeed from '../../components/TwitterFeed/TwitterFeed';
import './HomePage.css';

const HomePage: React.FC = () => {
  // Mock data for demonstration
  const featuredVerse = {
    reference: '2 Timothy 3:16-17',
    verses: 'All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness: That the man of God may be perfect, throughly furnished unto all good works.',
    explanation: 'This verse reminds us of the importance and purpose of Scripture in our lives.'
  };

  const recentPosts = [
    {
      title: 'The Gift of Salvation',
      date: 'March 15, 2025',
      content: 'Salvation is a free gift from God, not something we can earn through our own efforts. Ephesians 2:8-9 tells us, "For by grace are ye saved through faith; and that not of yourselves: it is the gift of God: Not of works, lest any man should boast."\n\nThis passage clearly explains that salvation comes through faith in Jesus Christ, not through our own works or merit. It is entirely a gift of God\'s grace.',
      type: 'salvation' as const,
      references: ['Ephesians 2:8-9', 'Romans 6:23', 'John 3:16']
    }
  ];

  // Mock tweets for demonstration
  const mockTweets = [
    {
      id: '1',
      text: 'Join us this Sunday as we explore the meaning of salvation through Christ. #ChristCenteredBaptist #Salvation',
      createdAt: '2025-03-20T10:30:00Z',
      username: 'christcenteredbaptist',
      name: 'Christ Centered Baptist',
      profileImageUrl: 'https://via.placeholder.com/48'
    },
    {
      id: '2',
      text: '"For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life." - John 3:16 #BibleVerse',
      createdAt: '2025-03-18T14:15:00Z',
      username: 'christcenteredbaptist',
      name: 'Christ Centered Baptist',
      profileImageUrl: 'https://via.placeholder.com/48'
    }
  ];

  return (
    <div className="home-page">
      <section className="welcome-section">
        <h1>Welcome to Christ Centered Baptist</h1>
        <p className="welcome-message">
          We are dedicated to teaching Christ through the Bible. Our mission is to share the message of salvation
          and help believers grow in their faith through the study of God's Word.
        </p>
      </section>

      <section className="featured-verse-section">
        <h2>Featured Bible Verse</h2>
        <BibleVerseCard 
          reference={featuredVerse.reference}
          verses={featuredVerse.verses}
          explanation={featuredVerse.explanation}
        />
      </section>

      <section className="recent-posts-section">
        <h2>Recent Posts</h2>
        {recentPosts.map((post, index) => (
          <WeeklyPost
            key={index}
            title={post.title}
            date={post.date}
            content={post.content}
            type={post.type}
            references={post.references}
          />
        ))}
      </section>

      <section className="twitter-section">
        <TwitterFeed tweets={mockTweets} loading={false} error={null} />
      </section>
    </div>
  );
};

export default HomePage;
